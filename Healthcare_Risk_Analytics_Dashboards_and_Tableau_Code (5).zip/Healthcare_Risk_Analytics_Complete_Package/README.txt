Healthcare Risk Analytics — Project Package

Contents

1. Dashboard_PNGs/
   - 01_Clinical_Risk_Overview.png
   - 02_Lifestyle_and_Disease_Patterns.png
   - 03_Population_Health_Patterns.png
   These images provide visual previews of the three dashboards, created using the project dataset.

2. Tableau_Workbook_Code/
   - Healthcare_Risk_Analytics_Tableau.twbx: packaged Tableau workbook file.
   - Healthcare_Risk_Analytics.twb: Tableau workbook XML source.
   - healthcare_tableau_ready.csv: dataset used for the project.

Notes
The .twb/.twbx workbook has not been verified in Tableau Desktop. Open it in Tableau Desktop to check compatibility and confirm that it displays correctly before submission. The PNG images are previews and are not screenshots captured directly from Tableau.
